/*
 * IronBoyController.cpp
 *
 * Created: 2015-04-10 오후 2:52:22
 *  Author: bong
 */ 


#include "IronBoyController.h"


// default constructor
IronBoyController::IronBoyController()
{
	BroadcastMode=0;
	RobotID=ROBOT_ID_DEFAULT;

} //IronBoyController
IronBoyController::IronBoyController(uint8_t serial_port)
{
	BroadcastMode=0;
	RobotID=ROBOT_ID_DEFAULT;
	RobotSerialPort=serial_port;

} //IronBoyController
void IronBoyController::begin()
{
	IronBoyController_packet_init(RobotSerialPort);
}

void IronBoyController::setBroadcastMode(void)
{
	BroadcastMode = 1;
};
void IronBoyController::clearBroadcastMode(void)
{
	BroadcastMode = 0;
};
void IronBoyController::setRobotID(uint8_t id)
{
	RobotID = id;
};
uint8_t IronBoyController::getRobotID(void)
{
	return RobotID;
};
uint8_t IronBoyController::returnRobotID(void)
{
	if(BroadcastMode)
		return BROADCAST_ID;
	else
		return RobotID;
};

