﻿/*
 * IronBoyController.h
 *
 * Created: 2015-04-10 오후 3:09:07
 *  Author: bong
 */ 


#ifndef IRONBOYCONTROLLER_H_
#define IRONBOYCONTROLLER_H_




#define ROBOT_ID_DEFAULT COMM_PACKET_DEFAULT_ID

#include "utility/hardware.h"
#include "utility/comm_packet_protocol.h"

#include "utility/PiezoDriver.h"
#include "utility/LedDriver.h"
#include "utility/ActuatorDriver.h"
#include "utility/MotionDriver.h"
#include "utility/ParameterDriver.h"

#define BROADCAST_ID 254

class	IronBoyController
{
//variables
private:
	uint8_t RobotID;
	uint8_t RobotSerialPort;
	uint8_t BroadcastMode;
	uint8_t send_transmit_tag;
public:
	
	PiezoDriver Piezo;
	LedDriver Led;
	ActuatorDriver Servo;
	MotionDriver Motion;
	ParameterDriver Parameter;
//functions
public:
	IronBoyController();
	IronBoyController(uint8_t serial_port);
	void begin();
	void setBroadcastMode(void);
	void clearBroadcastMode(void);
	void setRobotID(uint8_t id);
	uint8_t getRobotID(void);
	uint8_t returnRobotID(void);

};

extern IronBoyController IronBoyControl;
//extern SoftwareSerial mySerial;
#endif /* IRONBOYCONTROLLER_H_ */