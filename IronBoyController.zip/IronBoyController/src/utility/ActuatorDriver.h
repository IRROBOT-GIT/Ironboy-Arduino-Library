﻿/*
 * ActuatorDriver.h
 *
 * Created: 2015-05-21 오후 7:11:31
 *  Author: bong
 */ 


#ifndef ACTUATORDRIVER_H_
#define ACTUATORDRIVER_H_


class ActuatorDriver {
	//variables
	private:
	


	//functions
	public:
	ActuatorDriver();
	void writeActuatorPosition(uint8_t _id,int16_t _position, bool move, bool torque);
	void writeActuatorRawPosition(uint8_t _id,int16_t _position);
	int ConvertJoint2Angle(char dir, int value);
	int ConvertPosition2Angle(protocol_data_16bit_t pose_data);

}; //ActuatorDriver


#endif /* ACTUATORDRIVER_H_ */