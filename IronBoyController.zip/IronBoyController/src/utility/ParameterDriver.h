﻿/*
 * ParameterDriver.h
 *
 * Created: 2015-05-21 오후 7:11:31
 *  Author: bong
 */ 


#ifndef PARAMETERDRIVER_H_
#define PARAMETERDRIVER_H_


class ParameterDriver {
	//variables
	private:



	//functions
	public:
	ParameterDriver();
	result_status StoreBaseParameter(uint8_t		battery_full_voltage,			// (40~255)
										uint8_t		battery_low_warning_voltage,	// (40~255)
										uint8_t		motion_speed_rate,	// (50~200)
										uint8_t		*balance_PID, //Kp,Ki,Kd (0~255)
										uint8_t		auto_recovery_trigger_angle,	//(1~90)
										uint8_t		auto_recovery_front_down_motion,	//(0~199)
										uint8_t		auto_recovery_rear_down_motion,		//(0f~199)
										uint8_t		function_enable_byte);
	result_status RealtimeFunction(uint8_t motion_speed_rate, uint8_t	realtime_function_enable);
	result_status FeedBackRobotData(uint8_t feedback_num, protocol_header_t *recv_buf_head);
	result_status Ping(void);
	protocol_feedback_robot_status_t ReadRobotStatus(void);
	protocol_feedback_pose_capture_t PoseCapture(void);
	protocol_store_zero_position_t ReadRobotZero(void);
	protocol_feedback_base_parameter_t ReadRobotParameter(void);
	protocol_store_default_pose_t ReadRobotDefaultPose(void);
	protocol_store_activity_property_t ReadRobotProperty(void);



}; //ParameterDriver


#endif /* PARAMETERDRIVER_H_ */