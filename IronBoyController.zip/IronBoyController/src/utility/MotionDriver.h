﻿/*
 * MotionDriver.h
 *
 * Created: 2015-05-21 오후 7:11:31
 *  Author: bong
 */ 


#ifndef MOTIONDRIVER_H_
#define MOTIONDRIVER_H_


class MotionDriver {
	//variables
	private:



	//functions
	public:
	MotionDriver();
	protocol_feedback_execute_robot_motion_t Play(uint8_t MotionNum);
	result_status ExecuteRobotMotion(uint8_t MotionNum, protocol_feedback_execute_robot_motion_t *recv_buf);
	result_status WriteMonoStep(uint8_t step_moving_time, 
									uint8_t step_led, bool step_led_enable,
									uint8_t step_piezo, bool step_piezo_enable,
									int16_t step_reference_pitch, int16_t step_reference_roll,
									 int16_t *position);
	result_status MotionCaptureEnable(protocol_servo_bit_t	pose_capture_enable);
									 
 result_status StoreActivityProperty(uint8_t		motion,		// (0~199)
									 uint8_t		step_size,			// (0~24)
									 uint8_t		repeat_start_step,	// (1~23)
									 uint8_t		repeat_end_step,	// (1~23)
									 uint8_t		repeat_acceleration_rate,	//(100~250)
									 uint8_t		repeat_acceleration_count,	//(0~15)
									 uint8_t		next_motion,		//(0~200,255)
									 uint8_t		motion_function_enable_byte,	// (0~255)
									 char		*motion_name );
									 
	

}; //MotionDriver


#endif /* MOTIONDRIVER_H_ */