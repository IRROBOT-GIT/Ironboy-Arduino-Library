﻿/*
 * comm_packet_protocol.h
 *
 * Created: 2015-04-14 오후 2:18:35
 *  Author: bong
 */ 


#ifndef COMM_PACKET_PROTOCOL_H_
#define COMM_PACKET_PROTOCOL_H_

#include <Arduino.h>

#include "comm_protocol_format.h"

#define COMM_PACKET_BROADCAST_ID		254
#define COMM_PACKET_DEFAULT_ID			1

#define COMM_PACKET_BAUDRATE			57600
#define ROBOT_CONTROLLER_COM_PORT_UART	0
#define ROBOT_CONTROLLER_COM_PORT_IO	1
//extern SoftwareSerial mySerial;

#define STATUS_OK	0
#define STATUS_ERR	1

typedef int result_status;

extern result_status IronBoyController_packet_init(uint8_t port);
extern result_status IronBoyController_packet_send(protocol_header_t *ptr_buf);
extern result_status IronBoyController_packet_receive(protocol_header_t *ptr_buf);

extern uint8_t get_tag(void);
extern protocol_data_16bit_t convert_int16_to_protocol_data_16bit(int16_t data);
extern protocol_data_actuator_t convert_int16_to_protocol_data_zero_position(int16_t data,bool _move, bool _torque);

#endif /* COMM_PACKET_PROTOCOL_H_ */