﻿/*
 * MotionDriver.cpp
 *
 * Created: 2015-05-21 오후 7:11:08
 *  Author: bong
 */ 

#include "hardware.h"
#include "comm_packet_protocol.h"
#include <IronBoyController.h>
#include "MotionDriver.h"
#include "comm_protocol_format.h"



// default constructor
MotionDriver::MotionDriver()
{
	
}

/*
// default destructor
MotionDriver::~MotionDriver()
{
} //~MotionDriver
*/

protocol_feedback_execute_robot_motion_t MotionDriver::Play(uint8_t MotionNum)
{
	 protocol_feedback_execute_robot_motion_t feedback;
	 this->ExecuteRobotMotion(MotionNum, &feedback);
	 return feedback;
}


result_status MotionDriver::ExecuteRobotMotion(uint8_t MotionNum, protocol_feedback_execute_robot_motion_t *recv_buf)
{
	protocol_execute_robot_motion_t buf;
	uint8_t id=IronBoyControl.returnRobotID();
	//buf.head.path=
	buf.head.command=PACKET_execute_robot_motion;
	buf.head.size=sizeof(protocol_execute_robot_motion_t);
	buf.transmit_tag=get_tag();
	buf.robot_motion=MotionNum;
	buf.analog_trim[0][0].abs_val=0;
	buf.analog_trim[0][1].abs_val=0;
	buf.analog_trim[1][0].abs_val=0;
	buf.analog_trim[1][1].abs_val=0;

	IronBoyController_packet_send((protocol_header_t *)(&buf));

		if(id<COMM_PACKET_BROADCAST_ID)
		{
			
			{
				if(IronBoyController_packet_receive((protocol_header_t *)(recv_buf))==STATUS_OK)
				return STATUS_OK;
				
				//IronBoyController_packet_send((protocol_header_t *)(&buf));
			}
			}
		else
		{
			return STATUS_OK;
		}

	return STATUS_ERR;
	
}

result_status MotionDriver::WriteMonoStep(uint8_t step_moving_time,
											uint8_t step_led, bool step_led_enable,
											uint8_t step_piezo, bool step_piezo_enable,
											int16_t step_reference_pitch,
											int16_t step_reference_roll,
											int16_t *position) //, protocol_feedback_ack_t *recv_buf)
{
	uint8_t i;
	protocol_write_mono_step_t buf;
	protocol_feedback_ack_t recv_buf;
	uint8_t id=IronBoyControl.returnRobotID();
	//buf.head.path=
	buf.head.command=PACKET_write_mono_step;
	buf.head.size=sizeof(protocol_write_mono_step_t);
	buf.transmit_tag=get_tag();
	buf.step_moving_time=step_moving_time;
	buf.step_led.table_num=step_led;
	buf.step_piezo.table_num=step_piezo;
	
	if(step_led_enable==true)	buf.step_led._enable=1;
	else buf.step_led._enable=0;
	if(step_piezo_enable==true)	buf.step_piezo._enable=1;
	else buf.step_piezo._enable=0;
	
	buf.step_reference[0]=convert_int16_to_protocol_data_16bit(step_reference_pitch);
	buf.step_reference[1]=convert_int16_to_protocol_data_16bit(step_reference_roll);
	for(i=0;i<ROBOT_ACTUATOR_MAX;i++)
	{
		buf.position[i]=convert_int16_to_protocol_data_zero_position(*(position+i),true,true);
	}
	
	IronBoyController_packet_send((protocol_header_t *)(&buf));

	if(id<COMM_PACKET_BROADCAST_ID)
	{


			if(IronBoyController_packet_receive((protocol_header_t *)(&recv_buf))==STATUS_OK)
			return STATUS_OK;
			

	}
	else
	{
		return STATUS_OK;
	}
	
	return STATUS_ERR;
	
}

result_status MotionDriver::MotionCaptureEnable(protocol_servo_bit_t	pose_capture_enable)
{
	protocol_pose_capture_enable_t buf;
	protocol_feedback_ack_t recv_buf;
	uint8_t id=IronBoyControl.returnRobotID();
	//buf.head.path=
	buf.head.command=PACKET_pose_capture_enable;
	buf.head.size=sizeof(protocol_pose_capture_enable_t);
	buf.transmit_tag=get_tag();
	buf.pose_capture_enable=pose_capture_enable;
	
	IronBoyController_packet_send((protocol_header_t *)(&buf));
	
	if(id<COMM_PACKET_BROADCAST_ID)
	{

			if(IronBoyController_packet_receive((protocol_header_t *)(&recv_buf))==STATUS_OK)
			return STATUS_OK;
			

	}
	else
	{
		return STATUS_OK;
	}
	
	return STATUS_ERR;
}



//protocol_store_activity_property_t
result_status MotionDriver::StoreActivityProperty(
	uint8_t		motion,		// (0~199)
	uint8_t		step_size,			// (0~24)
	uint8_t		repeat_start_step,	// (1~23)
	uint8_t		repeat_end_step,	// (1~23)
	uint8_t		repeat_acceleration_rate,	//(100~250)
	uint8_t		repeat_acceleration_count,	//(0~15)
	uint8_t		next_motion,		//(0~200,255)
	uint8_t		motion_function_enable_byte,	// (0~255)
	char		motion_name[MOTION_NAME_MAX])
{
	protocol_store_activity_property_t buf;
	protocol_feedback_ack_t recv_buf;
	uint8_t id=IronBoyControl.returnRobotID();
	buf.head.command=PACKET_store_activity_property;
	buf.head.size=sizeof(protocol_store_activity_property_t);
	buf.transmit_tag=get_tag();
	buf.motion = motion;
	buf.step_size = step_size;
	buf.repeat_start_step = repeat_start_step;
	buf.repeat_end_step = repeat_end_step;
	buf.repeat_acceleration_rate = repeat_acceleration_rate;
	buf.repeat_acceleration_count = repeat_acceleration_count;
	buf.reserved_0 = 0xff;
	buf.reserved_1 = 0xff;
	buf.reserved_2 = 0xff;	
	buf.next_motion = next_motion;
	buf.motion_function_enable_byte = motion_function_enable_byte;

	for(char index =0;index<MOTION_NAME_MAX;index++)
	{
		buf.motion_name[index] = motion_name[index];
	}

	IronBoyController_packet_send((protocol_header_t *)(&buf));
	
	if(id<COMM_PACKET_BROADCAST_ID)
	{

		if(IronBoyController_packet_receive((protocol_header_t *)(&recv_buf))==STATUS_OK)
		return STATUS_OK;
			

	}
	else
	{
		return STATUS_OK;
	}
	
	return STATUS_ERR;
}	// 0xFF
  //Feedback 120과 동일)
