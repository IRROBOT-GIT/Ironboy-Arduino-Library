﻿/*
 * hardware.h
 *
 * Created: 2015-04-14 오후 2:25:43
 *  Author: bong
 */ 


#ifndef HARDWARE_H_
#define HARDWARE_H_


#include <Arduino.h>
#include "utility/complier.h"


#define LEONARDO 0

#define ARDUINO_BOARD 0 //LEONARDO


#endif /* HARDWARE_H_ */