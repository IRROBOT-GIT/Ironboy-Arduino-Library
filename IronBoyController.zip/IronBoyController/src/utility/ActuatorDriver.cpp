﻿/*
 * ActuatorDriver.cpp
 *
 * Created: 2015-05-21 오후 7:11:08
 *  Author: bong
 */ 

#include "hardware.h"

#include "comm_packet_protocol.h"
#include "ActuatorDriver.h"



// default constructor
ActuatorDriver::ActuatorDriver()
{
	
	
} //ActuatorDriver

/*
// default destructor
ActuatorDriver::~ActuatorDriver()
{
} //~ActuatorDriver
*/


void ActuatorDriver::writeActuatorPosition(uint8_t _id,int16_t _position,bool move, bool torque)
{
	protocol_write_actuator_position_t buf;
	//buf.head.path=
	buf.head.command=PACKET_write_actuator_position;
	buf.head.size=sizeof(protocol_write_actuator_position_t);
	buf.id=_id;
		
	if(move==true) buf.position.move=1;
	else  buf.position.move=0;
	
	if(torque==true) buf.position.torque=1;
	else  buf.position.torque=0;
	
	if(_position<0)
	{
		buf.position.sign=0;
		_position=-_position;
	}
	else	buf.position.sign=1;
	buf.position.abs_val=_position;
	
	IronBoyController_packet_send((protocol_header_t *)(&buf));
}

void ActuatorDriver::writeActuatorRawPosition(uint8_t _id,int16_t _position)
{
	protocol_write_actuator_position_t buf;
	//buf.head.path=
	buf.head.command=PACKET_write_actuator_raw_position;
	buf.head.size=sizeof(protocol_write_actuator_raw_position_t);
	buf.id=_id;
	
	if(_position<0)
	{
		buf.position.sign=0;
		_position=-_position;
	}
	else	buf.position.sign=1;
	
	buf.position.abs_val=_position;
	IronBoyController_packet_send((protocol_header_t *)(&buf));
}

int ActuatorDriver::ConvertJoint2Angle(char dir, int value)
{
	if(dir == 0) {
		value=-value;  //when angle_dir is 0, joint angle value is negative.
	}
	return value;
}

int ActuatorDriver::ConvertPosition2Angle(protocol_data_16bit_t pose_data)
{
	char dir = pose_data.sign;
	int value = pose_data.abs_val;
	if(dir == 0) {
		value=-value;  //when angle_dir is 0, joint angle value is negative.
	}
	return value;
}
