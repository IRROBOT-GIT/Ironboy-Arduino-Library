﻿/*
 * LedDriver.cpp
 *
 * Created: 2015-05-21 오후 7:11:08
 *  Author: bong
 */ 

#include "hardware.h"
#include "comm_packet_protocol.h"
#include "LedDriver.h"



// default constructor
LedDriver::LedDriver()
{
	
}
LedDriver::LedDriver(uint8_t _bright,uint8_t _red,uint8_t _green, uint8_t _blue)
{
	bright=_bright;
	red=_red;
	green=_green;
	blue=_blue;
	
} //LedDriver

/*
// default destructor
LedDriver::~LedDriver()
{
} //~LedDriver
*/



void LedDriver::ChestFullColor(uint8_t _bright,uint8_t _red,uint8_t _green, uint8_t _blue)
{
	protocol_write_chest_led_t buf;
	//buf.head.path=
	buf.head.command=PACKET_write_chest_led;
	buf.head.size=sizeof(protocol_write_chest_led_t);
	buf.chest_led_bright=_bright;
	buf.chest_led_red=_red;
	buf.chest_led_green=_green;
	buf.chest_led_blue=_blue;
	IronBoyController_packet_send((protocol_header_t *)(&buf));
}
