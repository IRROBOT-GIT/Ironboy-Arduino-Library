/* 
* PiezoDriver.cpp
*
* Created: 2015-04-16 오전 11:10:05
* Author: bong
*/

#include "hardware.h"
#include "comm_packet_protocol.h"
#include "PiezoDriver.h"



// default constructor
PiezoDriver::PiezoDriver()
{
	
}
PiezoDriver::PiezoDriver(uint8_t _octave,uint8_t _syllable, uint8_t _beat)
{
	octave=_octave;
	syllable=_syllable;
	beat=_beat;
	
} //PiezoDriver

/*
// default destructor
PiezoDriver::~PiezoDriver()
{
} //~PiezoDriver
*/



void PiezoDriver::playSound(uint8_t _octave,uint8_t _syllable, uint8_t _beat)
{
	protocol_write_sound_piezo_t buf;
	//buf.head.path=
	buf.head.command=PACKET_write_sound_piezo;
	buf.head.size=sizeof(protocol_write_sound_piezo_t);
	buf.octave=_octave;
	buf.syllable=_syllable;
	buf.beat=_beat;
	IronBoyController_packet_send((protocol_header_t *)(&buf));
}

void PiezoDriver::playSound(uint8_t _syllable, uint8_t _beat)
{
	playSound(octave,_syllable, _beat);
}

void PiezoDriver::setOctave(uint8_t _octave)
{
	octave=_octave;
}
//PiezoDriver Piezo=PiezoDriver(2,0,5);