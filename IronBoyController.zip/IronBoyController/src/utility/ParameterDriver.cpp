﻿/*
 * ParameterDriver.cpp
 *
 * Created: 2015-05-21 오후 7:11:08
 *  Author: bong
 */ 

#include "hardware.h"
#include "comm_packet_protocol.h"
#include <IronBoyController.h>
#include "ParameterDriver.h"



// default constructor
ParameterDriver::ParameterDriver()
{
	
}

/*
// default destructor
ParameterDriver::~ParameterDriver()
{
} //~ParameterDriver
*/



result_status ParameterDriver::StoreBaseParameter(uint8_t		battery_full_voltage,			// (40~255) FEEDBACK 4
uint8_t		battery_low_warning_voltage,	// (40~255)
uint8_t		motion_speed_rate,	// (50~200)
uint8_t		*balance_PID, //Kp,Ki,Kd (0~255)
uint8_t		auto_recovery_trigger_angle,	//(1~90)
uint8_t		auto_recovery_front_down_motion,	//(0~199)
uint8_t		auto_recovery_rear_down_motion,		//(0f~199)
uint8_t		function_enable_byte)
{
	protocol_store_base_parameter_t buf;
	protocol_feedback_ack_t recv_buf;
	uint8_t id=IronBoyControl.returnRobotID();
	//buf.head.path=
	buf.head.command=PACKET_execute_robot_motion;
	buf.head.size=sizeof(protocol_store_base_parameter_t);
	buf.transmit_tag=get_tag();
	buf.battery_full_voltage	= battery_full_voltage;			// (40~255)
	buf.battery_low_warning_voltage	= battery_low_warning_voltage;	// (40~255)
	buf.motion_speed_rate		= motion_speed_rate;	// (50~200)
	buf.balance_PID[0]			= *balance_PID; //Kp,Ki,Kd (0~255)
	buf.balance_PID[1]			= *(balance_PID+1); //Kp,Ki,Kd (0~255)
	buf.balance_PID[2]			= *(balance_PID+2); //Kp,Ki,Kd (0~255)
	buf.auto_recovery_trigger_angle	= auto_recovery_trigger_angle;	//(1~90)
	buf.auto_recovery_front_down_motion	= auto_recovery_front_down_motion;	//(0~199)
	buf.auto_recovery_rear_down_motion	= auto_recovery_rear_down_motion;		//(0~199)
	buf.function_enable_byte	= function_enable_byte;	// (0~255)
	buf.reserved = 0xff;

	IronBoyController_packet_send((protocol_header_t *)(&buf));
	
	if(id<COMM_PACKET_BROADCAST_ID)
	{

			if(IronBoyController_packet_receive((protocol_header_t *)(&recv_buf))==STATUS_OK)
			return STATUS_OK;
			

	}
	else
	{
		return STATUS_OK;
	}
	
	return STATUS_ERR;
	
}

result_status ParameterDriver::RealtimeFunction(uint8_t motion_speed_rate, uint8_t	realtime_function_enable)
{
	uint8_t i;
	protocol_realtime_function_enable_t buf;
	protocol_feedback_ack_t recv_buf;
	uint8_t id=IronBoyControl.returnRobotID();
	//buf.head.path=
	buf.head.command=PACKET_write_mono_step;
	buf.head.size=sizeof(protocol_write_mono_step_t);
	buf.transmit_tag=get_tag();
	buf.motion_speed_rate=motion_speed_rate;
	buf.realtime_function_enable	= realtime_function_enable;	// (0~255)
	
	IronBoyController_packet_send((protocol_header_t *)(&buf));

	if(id<COMM_PACKET_BROADCAST_ID)
	{

			if(IronBoyController_packet_receive((protocol_header_t *)(&recv_buf))==STATUS_OK)
			return STATUS_OK;
			

	}
	else
	{
		return STATUS_OK;
	}
	
	return STATUS_ERR;
	
}

result_status ParameterDriver::FeedBackRobotData(uint8_t feedback_num, protocol_header_t *recv_buf_head)
{
	protocol_request_feedback_robot_data_t buf;
	uint8_t id=IronBoyControl.returnRobotID();
	//buf.head.path=
	buf.head.command=PACKET_request_feedback_robot_data;
	buf.head.size=sizeof(protocol_request_feedback_robot_data_t);
	buf.transmit_tag=get_tag();
	buf.feedback_num=feedback_num;


	IronBoyController_packet_send((protocol_header_t *)(&buf));
	
	if(id<COMM_PACKET_BROADCAST_ID)
	{

			if(IronBoyController_packet_receive((protocol_header_t *)(recv_buf_head))==STATUS_OK)
			return STATUS_OK;

	}
	else
	{
		return STATUS_OK;
	}
	
	return STATUS_ERR;
}

result_status ParameterDriver::Ping(void)
{
	protocol_feedback_ack_t feedback;
	
	if(this->FeedBackRobotData(PACKET_feedback_ack,(protocol_header_t *)&feedback)==STATUS_OK)
	{
		if(feedback.head.command==PACKET_feedback_ack)  return STATUS_OK;
		else return STATUS_ERR;
	}
}
protocol_feedback_robot_status_t ParameterDriver::ReadRobotStatus(void)
{
	protocol_feedback_robot_status_t feedback;
	this->FeedBackRobotData(PACKET_feedback_robot_status,(protocol_header_t *)&feedback);
	return feedback;
}
protocol_feedback_pose_capture_t ParameterDriver::PoseCapture(void)
{
	protocol_feedback_pose_capture_t feedback;
	this->FeedBackRobotData(PACKET_feedback_pose_capture,(protocol_header_t *)&feedback);
	return feedback;
}

protocol_store_zero_position_t ParameterDriver::ReadRobotZero(void)
{
	protocol_store_zero_position_t feedback;
	this->FeedBackRobotData(PACKET_feedback_zero_position,(protocol_header_t *)&feedback);
	return feedback;
}

protocol_feedback_base_parameter_t ParameterDriver::ReadRobotParameter(void)
{
	protocol_feedback_base_parameter_t feedback;
	this->FeedBackRobotData(PACKET_feedback_base_parameter,(protocol_header_t *)&feedback);
	return feedback;
}

protocol_store_default_pose_t ParameterDriver::ReadRobotDefaultPose(void)
{
	protocol_store_default_pose_t feedback;
	this->FeedBackRobotData(PACKET_feedback_default_pose,(protocol_header_t *)&feedback);
	return feedback;
}

protocol_store_activity_property_t ParameterDriver::ReadRobotProperty(void)
{
	protocol_store_activity_property_t feedback;
	this->FeedBackRobotData(PACKET_feedback_activity_property,(protocol_header_t *)&feedback);
	return feedback;
}