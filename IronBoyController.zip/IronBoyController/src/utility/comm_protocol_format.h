﻿/*
 * comm_protocol_format.h
 *
 * Created: 2015-04-14 오후 2:04:53
 *  Author: bong
 */ 


#ifndef COMM_PROTOCOL_FORMAT_H_
#define COMM_PROTOCOL_FORMAT_H_


#ifndef INERNAL_DEFINE_INCLUDE
	
	#define ROBOT_ACTUATOR_MAX	24
	#define MOTION_NAME_MAX	60

#endif

// Commmand
#define PACKET_execute_robot_motion					1
#define PACKET_write_actuator_raw_position			2
#define PACKET_write_actuator_position				3
#define PACKET_write_mono_step						4
#define PACKET_realtime_function_enable				5
#define PACKET_pose_capture_enable					6
#define PACKET_robot_factory_reset					100
#define PACKET_store_zero_position					101
#define PACKET_store_base_parameter					102
#define PACKET_store_default_pose					103
#define PACKET_store_activity_property				110
#define PACKET_store_motion_step					111
#define PACKET_request_feedback_activity_property	120
#define PACKET_request_feedback_motion_step			121
#define PACKET_request_feedback_robot_data			127
#define PACKET_write_chest_led						128
#define PACKET_write_sound_piezo					129
/*
#define IRB_PLAY_MOTION PACKET_execute_robot_motion					//1
#define PACKET_write_actuator_raw_position			//2
#define PACKET_write_actuator_position				//3
#define PACKET_write_mono_step						//4
#define PACKET_realtime_function_enable				//5
#define PACKET_pose_capture_enable					//6
#define PACKET_robot_factory_reset					//100
#define PACKET_store_zero_position					//101
#define PACKET_store_base_parameter					//102
#define PACKET_store_default_pose					//103
#define PACKET_store_activity_property				//110
#define PACKET_store_motion_step					//111
#define PACKET_request_feedback_activity_property	//120
#define PACKET_request_feedback_motion_step			//121
#define PACKET_request_feedback_robot_data			//127
#define PACKET_write_chest_led						//128
#define PACKET_write_sound_piezo					//129
*/
//Feedback Number
#define PACKET_feedback_ack							1
#define PACKET_feedback_robot_status				2
#define PACKET_feedback_zero_position				3
#define PACKET_feedback_base_parameter				4
#define PACKET_feedback_default_pose				5
#define PACKET_feedback_pose_capture				6
#define PACKET_feedback_execute_robot_motion		7
#define PACKET_feedback_zero_pose_capture			8

#define PACKET_feedback_activity_property			120
#define PACKET_feedback_motion_step					121


typedef union protocol_data_8bit_{
	uint8_t val;
	#ifdef _fBitfield_enable
	struct {
	uint8_t abs_val			:7;
	uint8_t sign			:1;
	};
	#endif
} protocol_data_8bit_t;

typedef union protocol_data_16bit_{
	uint16_t val;
	#ifdef _fBitfield_enable
	struct {
		uint16_t abs_val		:15;
		uint16_t sign		:1;
	};
	#endif
} protocol_data_16bit_t;


typedef union protocol_data_actuator_{
	uint16_t val;
	#ifdef _fBitfield_enable
	struct {
		uint16_t abs_val		:9;
		uint16_t reserved	:4;
		uint16_t move		:1;
		uint16_t torque		:1;
		uint16_t sign		:1;
	};
	#endif
} protocol_data_actuator_t;


typedef union protocol_data_zero_position_{
	uint8_t val;
	#ifdef _fBitfield_enable
	struct {
		uint16_t abs_val		:10;
		uint16_t reserved		:4;
		uint16_t _enable		:1;
		uint16_t _dir			:1;
	};
	#endif
} protocol_data_zero_position_t;
				
typedef union protocol_servo_bit_{
	uint8_t group[3];
	#ifdef _fBitfield_enable
	struct {
		#ifdef NAME_BIT_T
		NAME_BIT_T(servo,0,1,2,3,4,5,6,7);
		NAME_BIT_T(servo,8,9,10,11,12,13,14,15);
		NAME_BIT_T(servo,16,17,18,19,20,21,22,23);
		#else
		struct {
			uint8_t servo0		:1;
			uint8_t servo1		:1;
			uint8_t servo2		:1;
			uint8_t servo3		:1;
			uint8_t servo4		:1;
			uint8_t servo5		:1;
			uint8_t servo6		:1;
			uint8_t servo7		:1;
		};
		struct {
			uint8_t servo8		:1;
			uint8_t servo9		:1;
			uint8_t servo10		:1;
			uint8_t servo11		:1;
			uint8_t servo12		:1;
			uint8_t servo13		:1;
			uint8_t servo14		:1;
			uint8_t servo15		:1;
		};
		struct {
			uint8_t servo16		:1;
			uint8_t servo17		:1;
			uint8_t servo18		:1;
			uint8_t servo19		:1;
			uint8_t servo20		:1;
			uint8_t servo21		:1;
			uint8_t servo22		:1;
			uint8_t servo23		:1;
		};
		#endif
	};
	#endif
} protocol_servo_bit_t;

typedef union protocol_data_table_enable_{
	uint8_t val;
	#ifdef _fBitfield_enable
	struct {
		uint8_t table_num	:6;
		uint8_t reserved	:1;
		uint8_t _enable		:1;
	};
	#endif
} protocol_data_table_enable_t;

typedef struct protocol_header_{
	uint8_t path;
    uint8_t size;
	uint8_t command;
	} protocol_header_t;

//Instruction 1  로봇 동작 실행 (Packet Size: 15 Byte)	//Feedback 1 수신
typedef struct protocol_execute_robot_motion_{
	protocol_header_t head;     // command: 0x01, size: 15
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		robot_motion;		// Robot Motion Number(0~255)
	protocol_data_8bit_t		analog_trim[2][2];			// Motion Trim (-127 ~ 127)
	uint8_t		reserved_0;			// 0xFF
	uint8_t		reserved_1;			// 0xFF
	uint8_t		reserved_2;			// 0xFF
	uint8_t		reserved_3;			// 0xFF
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_execute_robot_motion_t;


//Instruction 2  액츄에이터 실제 위치값(0~1023) 이동 (Packet Size: 8 Byte)		
typedef struct protocol_write_actuator_raw_position_{
	protocol_header_t head;			// command: 0x02, size: 8
	uint8_t		id;					// Actuator ID (0~23)
	uint16_t	raw_position;		// Raw Position [LOW | HIGH] (0~1023)
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_write_actuator_raw_position_t;

//Instruction 3  액츄에이터 목표 위치값(-511~511) 이동 (Packet Size: 8 Byte)	
typedef struct protocol_write_actuator_position_{
	protocol_header_t head;			// command: 0x03, size: 8
	uint8_t		id;					// Actuator ID (0~23)
	protocol_data_actuator_t	position;			// Position [LOW | HIGH] (-511~511)
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_write_actuator_position_t;

//Instruction 4  단일 스텝 이동 (Packet Size: 64 Byte)	
typedef struct protocol_write_mono_step_{
	protocol_header_t head;			// command: 0x04, size: 64
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		step_moving_time;	// Step Moving Time(1~255), unit: 0.05sec
	uint8_t		reserved_0;			// 0xFF
	uint8_t		reserved_1;			// 0xFF
	uint8_t		reserved_2;			// 0xFF
	protocol_data_table_enable_t		step_led;			// Step Image (0~99) | MSB(enable)
	protocol_data_table_enable_t		step_piezo;			// Step Sound (0~99) | MSB(enable)
	protocol_data_16bit_t	step_reference[2];		// Pitch[LOW | HIGH](-900~900), Roll[LOW | HIGH](-1800~1799) unit: 0.1º 
	protocol_data_actuator_t	position[ROBOT_ACTUATOR_MAX];		// Position [LOW | HIGH] (-511~511)
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_write_mono_step_t;

//Instruction 5  로봇 실시간 기능 설정 (Packet Size: 10 Byte)
typedef struct protocol_realtime_function_enable_{
	protocol_header_t head;			// command: 0x04, size: 64
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		motion_speed_rate;	// Step Moving Time(1~255), unit: 0.05sec
	uint8_t		reserved_0;			// 0xFF
	uint8_t		reserved_1;			// 0xFF
	uint8_t		realtime_function_enable;			// 0xFF
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_realtime_function_enable_t;

//Instruction 6  로봇 자세 캡쳐 설정 (Packet Size: 10 Byte)
typedef struct protocol_pose_capture_enable_{
	protocol_header_t head;			// command: 0x04, size: 64
	uint8_t		transmit_tag;		// tag(0~255)
	protocol_servo_bit_t		pose_capture_enable;			// 0xFF
	uint8_t		reserved;			// 0xFF
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_pose_capture_enable_t;


//Instruction 100  로봇 설정 공장 초기화 (Packet Size: 7 Byte) //Feedback 1 수신
typedef struct protocol_robot_factory_reset_{
	protocol_header_t head;			// command: 0x64, size: 7
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		reserved;	    // (255 : Reset, 254 : Read, 0~253 : Set)
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_robot_factory_reset_t;


//Instruction 101  로봇 액츄에이터 기준위치값(0~1023) 저장 (Packet Size: 56 Byte) //Feedback 1 수신
typedef struct protocol_store_zero_position_{
	protocol_header_t head;			// command: 101, size: 56
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		reserved_0;			// 0xFF
	uint8_t		reserved_1;			// 0xFF
	protocol_data_zero_position_t	zero_position[ROBOT_ACTUATOR_MAX];		// Position [LOW | HIGH] (0~1023), Direction|Enable
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_store_zero_position_t;
#define IBC_Zero_Pose_t protocol_store_zero_position_t

//Instruction 102  로봇 기본 설정 저장 (Packet Size: 18 Byte) //Feedback 1 수신
typedef struct protocol_store_base_parameter_{
	protocol_header_t head;			// command: 102, size: 18
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		new_robot_id;		// (0~253)
	uint8_t		battery_full_voltage;			// (40~255)
	uint8_t		battery_low_warning_voltage;	// (40~255)
	uint8_t		motion_speed_rate;	// (50~200)
	uint8_t		balance_PID[3]; //Kp,Ki,Kd (0~255)
	uint8_t		auto_recovery_trigger_angle;	//(1~90)
	uint8_t		auto_recovery_front_down_motion;	//(0~199)
	uint8_t		auto_recovery_rear_down_motion;		//(0~199)
	uint8_t		function_enable_byte;	// (0~255)
	uint8_t		reserved;			// 0xFF
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_store_base_parameter_t;	

//Instruction 103  로봇 기본자세 저장 (Packet Size: 56 Byte) //Feedback 1 수신
typedef struct protocol_store_default_pose_{
	protocol_header_t head;			// command: 101, size: 56
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		reserved_0;			// 0xFF
	uint8_t		reserved_1;			// 0xFF
	protocol_data_16bit_t	position[ROBOT_ACTUATOR_MAX];		// Position [LOW | HIGH] (-511~511)
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_store_default_pose_t;
#define IBC_Default_Pose_t protocol_store_default_pose_t

//Instruction 110  로봇 동작 속성 저장 (Packet Size: 77 Byte) //Feedback 1 수신
typedef struct protocol_store_activity_property_{
	protocol_header_t head;			// command: 102, size: 18
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		motion;				// (0~199)
	uint8_t		step_size;			// (0~24)
	uint8_t		repeat_start_step;	// (1~23)
	uint8_t		repeat_end_step;	// (1~23)
	uint8_t		repeat_acceleration_rate;	//(100~250)
	uint8_t		repeat_acceleration_count;	//(0~15)
	uint8_t		reserved_0;			// 0xFF
	uint8_t		reserved_1;			// 0xFF
	uint8_t		reserved_2;			// 0xFF
	uint8_t		next_motion;		//(0~200,255)
	uint8_t		motion_function_enable_byte;	// (0~255)
	char		motion_name[MOTION_NAME_MAX];			// 0xFF
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_store_activity_property_t; //Feedback 120과 동일
#define IBC_Property_t protocol_store_activity_property_t

//Instruction 111  로봇 동작 스텝 저장 (Packet Size: 66 Byte) //Feedback 1 수신
typedef struct protocol_store_motion_step_{
	protocol_header_t head;			// command: 0x04, size: 64
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		motion;				// (0~199)
	uint8_t		step;				//	(0~23)
	uint8_t		step_move_time;	// Step Moving Time(1~255), unit: 0.01sec
	uint8_t		step_stop_time;	// Step Moving Time(0~255), unit: 0.01sec
	uint8_t		reserved_0;			// 0xFF
	uint8_t		reserved_1;			// 0xFF
	protocol_data_table_enable_t		step_led;			// Step Image (0~99) | MSB(enable)
	protocol_data_table_enable_t		step_piezo;			// Step Sound (0~99) | MSB(enable)
	protocol_data_16bit_t	step_reference[2];		// Pitch[LOW | HIGH](-900~900), Roll[LOW | HIGH](-1800~1799) unit: 0.1º
	protocol_data_actuator_t	position[ROBOT_ACTUATOR_MAX];		// Position [LOW | HIGH] (-511~511)
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_store_motion_step_t; //Feedback 121과 동일

//Instruction 120  로봇 동작 속성 Feedback 요청 (Packet Size: 8 Byte) //Feedback 120 수신
typedef struct protocol_request_feedback_activity_property_{
	protocol_header_t head;			// command: 0x78, size: 8
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		motion;				// (0~199)
	uint8_t		reserved;			// 0xFF
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_request_feedback_activity_property_t;

//Instruction 121  로봇 동작 스텝 Feedback 요청 (Packet Size: 9 Byte) //Feedback 121 수신
typedef struct protocol_request_feedback_motion_step_{
	protocol_header_t head;			// command: 0x79, size: 8
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		motion;				// (0~199)
	uint8_t		step;				// (0~23)
	uint8_t		reserved;			// 0xFF
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_request_feedback_motion_step_t;

//Instruction 127  로봇 데이터 Feedback 요청 (Packet Size: 7 Byte)
typedef struct protocol_request_feedback_robot_data_{
	protocol_header_t head;			// command: 0x7F, size: 7
	uint8_t		feedback_num;		// Feedback 번호(1~5)
	uint8_t		transmit_tag;		// tag(0~255)
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_request_feedback_robot_data_t;



//Instruction 128  LED 색상 출력 (Packet Size: 9 Byte)
typedef struct protocol_write_chest_led_{
	protocol_header_t head;			// command: 128, size: 9
	uint8_t chest_led_bright;		// LED 전체 밝기 (0 ~ 255)
	uint8_t chest_led_red;			// 적색 밝기 (0 ~ 255)
	uint8_t chest_led_green;		// 녹색 밝기 (0 ~ 255)
	uint8_t chest_led_blue;			// 청색 밝기 (0 ~ 255)
	uint8_t checksum;				// Check Sum( Robot ID + Command + ...)
} protocol_write_chest_led_t;

//Instruction 129  Piezo 소리 출력 (Packet Size: 8 Byte) 
typedef struct protocol_write_sound_piezo_{
	protocol_header_t head;			// command: 129, size: 8
	uint8_t octave;					// 옥타브 번호 (1 ~ 7)
	uint8_t syllable;				// 음 번호 (0 ~ 11)
	uint8_t beat;					// 음 길이 (1 ~ 255) 단위: 4 msec
	uint8_t checksum;				// Check Sum( Robot ID + Command + ...)
} protocol_write_sound_piezo_t;



//Feedback 1  명령 정상 수신 확인 (Packet Size: 6 Byte)
typedef struct protocol_feedback_ack_{
	protocol_header_t head;			// command: 1, size: 6
	uint8_t transmit_tag;			// tag(0~255)
	uint8_t		checksum;			// Check Sum( Robot ID + feedback number + transmit tag + ...)
} protocol_feedback_ack_t;
#define IBC_Ack_t protocol_feedback_ack_t

//Feedback 2  로봇 현재 상태 (Packet Size: 17 Byte)
typedef struct protocol_feedback_robot_status_{
	protocol_header_t head;				// command: 2, size: 17
	uint8_t		transmit_tag;			// tag(0~255)
	uint16_t	input_power_voltage;	// Input Power Voltage(400~2559) unit:10mV
	uint8_t		current_motion;			// Current Motion(0~255)
	uint8_t		next_motion;			// Next Motion(0~255)
	protocol_data_16bit_t	current_angle[3];	// Pitch[LOW | HIGH](-900~900), Roll[LOW | HIGH](-1800~1799), Yaw[LOW | HIGH](-1800~1799) unit: 0.1º
	uint8_t		function_status_byte;			// 0xFF
	uint8_t		checksum;				// Check Sum( Robot ID + feedback number + transmit tag + ...)
} protocol_feedback_robot_status_t;
#define IBC_Status_t protocol_feedback_robot_status_t


//Feedback 4  로봇 기본 설정 (Packet Size: 17 Byte) 
typedef struct protocol_feedback_base_parameter_{
	protocol_header_t head;			// command: 4, size: 17
	uint8_t transmit_tag;			// tag(0~255)
	uint8_t		battery_full_voltage;			// (40~255)
	uint8_t		battery_low_warning_voltage;	// (40~255)
	uint8_t		motion_speed_rate;		// (50~200)
	uint8_t		balance_PID[3];			//Kp,Ki,Kd (0~255)
	uint8_t		auto_recovery_trigger_angle;	//(1~90)
	uint8_t		auto_recovery_front_down_motion;//(0~199)
	uint8_t		auto_recovery_rear_down_motion;	//(0~199)
	uint8_t		function_enable_byte;			// (0~255)
	uint8_t		reserved;			// 0xFF
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_feedback_base_parameter_t;
#define IBC_Parameter_t protocol_feedback_base_parameter_t



//Feedback 6  로봇 현재자세 Feedback  (Packet Size: 58 Byte)
typedef struct protocol_feedback_pose_capture_{
	protocol_header_t	head;			// command: 6, size: 58
	uint8_t transmit_tag;			// tag(0~255)
	protocol_servo_bit_t		pose_capture_enable;			// 0xFF
	uint8_t						reserved;			// 0xFF
	protocol_data_16bit_t		position[ROBOT_ACTUATOR_MAX];		// Position [LOW | HIGH] (-511~511)
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_feedback_pose_capture_t;
#define IBC_Pose_Capture_t protocol_feedback_pose_capture_t

//Feedback 7  로봇 동작 실행 (Packet Size: 15 Byte)	
typedef struct protocol_feedback_execute_robot_motion_{
	protocol_header_t head;     // command: 7, size: 15
	uint8_t transmit_tag;			// tag(0~255)
	uint8_t		battery_remaining;		// battery remaining(0~100), unit:%
	protocol_data_16bit_t		current_angle[2];	// Pitch[LOW | HIGH](-900~900), Roll[LOW | HIGH](-1800~1799) unit: 0.1º
	uint8_t		reserved_0;			// 0xFF
	uint8_t		reserved_1;			// 0xFF
	uint8_t		reserved_2;			// 0xFF
	uint8_t		function_state_byte;			// 0xFF
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_feedback_execute_robot_motion_t;	// PACKET_execute_robot_motion
#define IBC_Motion_Status_t protocol_feedback_execute_robot_motion_t

//Feedback 8  로봇 영점 현재자세 Feedback  (Packet Size: 58 Byte)
typedef struct protocol_feedback_zero_pose_capture_{
	protocol_header_t	head;		// command: 8, size: 58
	uint8_t		transmit_tag;		// tag(0~255)
	protocol_servo_bit_t		pose_capture_enable;			// 0xFF
	uint8_t		reserved;			// 0xFF
	protocol_data_zero_position_t		position[ROBOT_ACTUATOR_MAX];		// Position [LOW | HIGH] (-511~511)
	uint8_t		checksum;			// Check Sum( Robot ID + Command + ...)
} protocol_feedback_zero_pose_capture_t;



#endif /* COMM_PROTOCOL_FORMAT_H_ */

/*


*/