/* 
* PiezoDriver.h
*
* Created: 2015-04-16 오전 11:10:05
* Author: bong
*/


#ifndef __PIEZODRIVER_H__
#define __PIEZODRIVER_H__

class PiezoDriver {
//variables
private:
	uint8_t octave;
	uint8_t syllable;
	uint8_t beat;

//functions
public:
	PiezoDriver();
	PiezoDriver(uint8_t _octave,uint8_t _syllable, uint8_t _beat);
	void playSound(uint8_t _octave,uint8_t _syllable, uint8_t _beat);
	void playSound(uint8_t _syllable, uint8_t _beat);
	void setOctave(uint8_t _octave);

}; //PiezoDriver

//extern PiezoDriver Piezo;
#endif //__PIEZODRIVER_H__
