﻿/*
 * LedDriver.h
 *
 * Created: 2015-05-21 오후 7:11:31
 *  Author: bong
 */ 


#ifndef LEDDRIVER_H_
#define LEDDRIVER_H_


class LedDriver {
	//variables
	private:
	uint8_t bright;
	uint8_t red;
	uint8_t green;
	uint8_t blue;


	//functions
	public:
	LedDriver();
	LedDriver(uint8_t _bright,uint8_t _red,uint8_t _green, uint8_t _blue);
	void ChestFullColor(uint8_t _bright,uint8_t _red,uint8_t _green, uint8_t _blue);
	

}; //LedDriver


#endif /* LEDDRIVER_H_ */