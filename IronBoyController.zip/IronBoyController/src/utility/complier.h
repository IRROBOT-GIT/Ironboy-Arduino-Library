﻿/*
 * complier.h
 *
 * Created: 2015-04-17 오후 4:16:00
 *  Author: bong
 */ 


#ifndef COMPLIER_H_
#define COMPLIER_H_

//typedef unsigned char uint8_t;
//typedef unsigned int  uint16_t;
//typedef signed int  int16_t

#define _fBitfield_enable

#endif /* COMPLIER_H_ */