﻿/*
 * comm_packet.c
 *
 * Created: 2015-04-14 오후 2:17:21
 *  Author: bong
 */ 

#include <Arduino.h>
#include "hardware.h"
#include "comm_packet_protocol.h"
#include <IronBoyController.h>
#include <SoftwareSerial.h>

#define PACKET_BUF_MAX			80

#define PACKET_RX_BUF_MAX	PACKET_BUF_MAX

#define PACKET_HEADER 0xFF
#define PACKET_HEADER_SIZE 2

#define PACKET_INDEX_ROBOT_ID	2
#define PACKET_INDEX_INST		3
#define PACKET_INDEX_BODY_BASE		4

#define PACKET_HEAD_SIZE PACKET_INDEX_BODY_BASE

SoftwareSerial mySerial(8, 9); // RX, TX
uint8_t serial_port;
 uint8_t PacketRxBuf[PACKET_RX_BUF_MAX];
uint8_t send_transmit_tag;

uint8_t read_comm_protocol_format_size(uint8_t command)
{
	uint8_t return_data;
	
	
	
	switch(command)
	{
		case PACKET_feedback_ack : //						1
		return_data=sizeof(protocol_feedback_ack_t);
		break;
		case PACKET_feedback_robot_status: //				2
		return_data=sizeof(protocol_feedback_robot_status_t);
		break;
		case PACKET_feedback_zero_position: //				3
		return_data=sizeof(protocol_store_zero_position_t);
		break;
		case PACKET_feedback_base_parameter: //				4
		return_data=sizeof(protocol_feedback_base_parameter_t);
		break;
		case PACKET_feedback_default_pose: //				5
		return_data=sizeof(protocol_store_default_pose_t);
		break;
		case PACKET_feedback_pose_capture: //				6
		return_data=sizeof(protocol_feedback_pose_capture_t);
		break;
		case PACKET_feedback_execute_robot_motion: //		7
		return_data=sizeof(protocol_feedback_execute_robot_motion_t);
		break;
		case PACKET_feedback_activity_property: //			120
		return_data=sizeof(protocol_store_activity_property_t);
		break;
		case PACKET_feedback_motion_step: //			121
		return_data=sizeof(protocol_store_motion_step_t);
		break;
		default:
		return_data=sizeof(protocol_header_t);
	};
	
	return return_data;
}
uint8_t read_comm_packet_format_size(uint8_t command)
{
	uint8_t return_data;
	
	return_data=read_comm_protocol_format_size(command);
	if(return_data>sizeof(protocol_header_t))
	{
		return_data=return_data-sizeof(protocol_header_t)+PACKET_HEAD_SIZE;
	}
	else return_data=0;
	
	return return_data;
	
}

result_status IronBoyController_packet_init(uint8_t port)
{
	serial_port=port;
	if(port==ROBOT_CONTROLLER_COM_PORT_IO)
	{
		// set the data rate for the SoftwareSerial port
		mySerial.begin(COMM_PACKET_BAUDRATE);
	}
	else
	{
		
		//TODO:: Please write your application code
		Serial1.begin(COMM_PACKET_BAUDRATE);
		
		#if (ARDUINO_BOARD==LEONARDO)
		while (!Serial1) {
			; // wait for serial port to connect. Needed for Leonardo only
		};
		//messageOut.begin(&Serial1);
		//messageIn.begin(&Serial1);
		#else
		//messageOut.begin(&Serial1);
		//messageIn.begin(&Serial1);
		#endif
	}
	return STATUS_OK;
}

result_status IronBoyController_packet_send(protocol_header_t *ptr_buf)
{
	int i;
	uint16_t c_sum=0;
	uint8_t temp;
	uint8_t ins=ptr_buf->command;
	uint8_t size=ptr_buf->size-1;
	uint8_t *buf=(unsigned char*)ptr_buf;
	uint8_t id=IronBoyControl.returnRobotID();
	
	if(serial_port==ROBOT_CONTROLLER_COM_PORT_IO)
	{
		mySerial.write(0xff);
		mySerial.write(0xff);
		mySerial.write(id); //IronBoyControl.getRobotID()); // robot id
		mySerial.write(ins); //inst
		c_sum=id;
		c_sum+=ins;
	
		for(i=sizeof(protocol_header_t);i<size;i++)
		{
			temp=*(buf+i);
			mySerial.write(temp); 
			c_sum+=temp;
		}
	
		c_sum+=15;
		mySerial.write(c_sum&0x00ff); // checksum
	}
	else
	{
	
		Serial1.write(0xff);
		Serial1.write(0xff);
		Serial1.write(id); //IronBoyControl.getRobotID()); // robot id
		Serial1.write(ins); //inst
		c_sum=id;
		c_sum+=ins;
		
		for(i=sizeof(protocol_header_t);i<size;i++)
		{
			temp=*(buf+i);
			Serial1.write(temp);
			c_sum+=temp;
		}
		c_sum+=15;
		Serial1.write(c_sum&0x00ff); // checksum
	}

	return STATUS_OK;
}

result_status IronBoyController_packet_receive(protocol_header_t *ptr_buf)
{
	 uint8_t received_flag=0;
	 uint8_t data;
	 uint8_t size=0xff;
	 uint8_t point=0;
	 uint8_t id=IronBoyControl.returnRobotID();
	unsigned long int index=0;
	do{

		if(serial_port==ROBOT_CONTROLLER_COM_PORT_IO)
		{
	
			if(mySerial.available()) {
				data = mySerial.read();
				received_flag=1;

			}
		}
		else if(serial_port==ROBOT_CONTROLLER_COM_PORT_UART)
		{

			while(Serial1.available()) {
				data = Serial1.read();
				received_flag=1;
				
			}
			
		}
		else
			return STATUS_ERR;
		if(received_flag)
		{

			PacketRxBuf[point]=data;
			/////////
			if(point<PACKET_HEADER_SIZE)
			{		       	
				if(data==PACKET_HEADER) point++;
				else
				 { 
					 //point=0;
					 //return STATUS_ERR;
			 
				}
			}
			else if(point==PACKET_INDEX_ROBOT_ID)
			{
						
				if((data!=id)||(data==PACKET_HEADER))
				{
					//point=0;
					//return STATUS_ERR;
		
				}
				else
				{
					point++;
				}
			
			}
			else if(point==PACKET_INDEX_INST)
			{
				point++;
				size=read_comm_packet_format_size(data);
			
				if(size==0)
					{  
						//point=0; 
						//return STATUS_ERR;
					
					}
					
						
			}
			else
			{
				point++;
			  
				if(point>=size)
				{
					uint16_t checksum=0;
					uint8_t i;
					for(i=2;i<(size-1);i++)
					{
						checksum+=(uint8_t)PacketRxBuf[i];
					}
					checksum = checksum + 0x0F;
					//point=0;
					if(data==(uint8_t)(checksum & 0x00ff))
					{
						
						uint8_t i;
						ptr_buf->size = size;
						ptr_buf->command = PacketRxBuf[PACKET_INDEX_INST]; 
						for(i=4;i<(size);i++)
						{
							*((uint8_t*)ptr_buf+i-1)=(uint8_t)PacketRxBuf[i];
						}
							
						
						return STATUS_OK;
					
					}
					else
					{
						  break;
					}
				
				 
				}	
				
					
				
			}

			received_flag=0;
		}
		//////////////
		index++;
		if(index>= 65534)
			return STATUS_ERR;
	}while(true);

	return	STATUS_OK ;
}

uint8_t get_tag(void)
{
	if(send_transmit_tag<255) send_transmit_tag++;
	else send_transmit_tag=0;
	
	return send_transmit_tag;
}

protocol_data_16bit_t convert_int16_to_protocol_data_16bit(int16_t data)
{
	protocol_data_16bit_t temp;
	if(data<0)
	{
		temp.abs_val=-data;
		temp.sign=0;
	}
	else
	{
		temp.abs_val=data;
		temp.sign=1;
	}
	return temp;
	
}

protocol_data_actuator_t convert_int16_to_protocol_data_zero_position(int16_t data,bool _move, bool _torque)
{
	protocol_data_actuator_t temp;
	if(data<0)
	{
		temp.abs_val=-data;
		temp.sign=0;
	}
	else
	{
		temp.abs_val=data;
		temp.sign=1;
	}
	if(_move) temp.move = 1;
	else temp.move = 0;
	if(_torque) temp.torque = 1;
	else temp.torque = 0;
	return temp;
}